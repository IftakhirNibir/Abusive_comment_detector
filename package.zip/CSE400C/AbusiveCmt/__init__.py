import pickle
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from langdetect import detect

def abusive_comment(comment):

    model = pickle.load(open("./ML_Models/svm_trained_model",'rb'))
    tfv = pickle.load(open("./ML_Models/tfv.pickle", 'rb'))
    model2 = pickle.load(open("./ML_Models/lr_model",'rb'))
    tfv2 = pickle.load(open("./ML_Models/tfv2.pickle", 'rb'))
    model3 = pickle.load(open("./ML_Models/lr_trained_model",'rb'))
    tfv3 = pickle.load(open("./ML_Models/tfv3.pickle", 'rb'))

    input = str(comment)

    w = ""
    for i in input:
        if i.isalnum() or i.isspace():
            w=w+i
            o = ""
    for j in w:
        if j.isdigit():
            continue
        else:
             o=o+j

    b = o.split()

    c = 0
    x = 0
    z = 0


    for i in range(len(b)):
        if detect(b[i]) == 'bn':
            x = x+1
        elif detect(b[i]) != 'bn':
            c = c+1
        else:
            z = z+1

    if x == len(b):
        dt = "Bangla"
    elif c == len(b):
        dt = "English"
    else:
        dt = "Banglish"


    if  dt == 'Bangla':
        comment_vect = tfv2.transform([input]) 
        pp = model2.predict_proba(comment_vect)[:,1]
        p = float(pp)
        if p>=0.5:
            return 'The Comment is Abusive '
        else:
            return "The Comment is not Abusive "
    elif dt == 'English':
        comment_vect = tfv.transform([input]) 
        pp = model.predict_proba(comment_vect)[:,1]
        p = float(pp)
        if p>=0.5:
            return 'The Comment is Abusive '
        else:
            return "The Comment is not Abusive "
    else:
        comment_vect = tfv3.transform([input]) 
        pp = model3.predict_proba(comment_vect)[:,1]
        p = float(pp)
        if p>=0.5:
            return 'The Comment is Abusive '
        else:
            return "The Comment is not Abusive "