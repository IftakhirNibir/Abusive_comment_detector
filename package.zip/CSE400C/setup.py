import setuptools 

setuptools.setup( 
    name='AbusiveCmt', 
    version='0.3', 
    author="Muhammad NMA", 
    author_email="nma@gmail.com", 
    description="This a abusive comment detector python package", 
    packages=setuptools.find_packages(), 
    classifiers=[ 
        "Programming Language :: Python :: 3", 
        "License :: OSI Approved :: MIT License", 
        "Operating System :: OS Independent", 
        ],
)
